<?php
include('header.php');

    if(!isset($_SESSION['id'])) {
        header("Location: main.php");
    } else {
        $idpic=$_GET['idpic'];
        $dbh = new PDO('mysql:host=localhost;dbname=pictionnary', 'test', 'test');
        $sql = $dbh->query("SELECT drawingcommands FROM drawings  WHERE idpic='".$idpic."'");
        $res= $sql->fetchAll(PDO::FETCH_ASSOC);

        $commands=$res;
        // ici, récupérer la liste des commandes dans la table DRAWINGS avec l'identifiant $_GET['id']
        // l'enregistrer dans la variable $commands


    }
    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset=utf-8 />
    <title>Pictionnary</title>
    <link rel="stylesheet" media="screen" href="css/styles.css" >
    <script>
        // la taille et la couleur du pinceau
        var size, color;
        // la dernière position du stylo
        var x0, y0;
        // le tableau de commandes de dessin à envoyer au serveur lors de la validation du dessin
        var drawingCommands = <?php echo $commands; ?>;

        window.onload = function() {
            var canvas = document.getElementById('myCanvas');
            canvas.width = 400;
            canvas.height= 400;
            var context = canvas.getContext('2d');

            var clickX = new Array();
            var clickY = new Array();
            var clickDrag = new Array();


            var start = function(c) {
                // complétez

                    context.strokeStyle = c.color;
                    context.lineJoin = "round";
                    context.lineWidth = c.size;

                clickX= c.x;
                clickY= c.y;
                clickDrag= c.drag;

                    for(var i=0; i < clickX.length; i++) {
                        context.beginPath();
                        if(clickDrag[i] && i){
                            context.moveTo(clickX[i-1], clickY[i-1]);
                        }else{
                            context.moveTo(clickX[i]-1, clickY[i]);
                        }
                        context.lineTo(clickX[i], clickY[i]);
                        context.closePath();
                        context.stroke();
                    }

            }

                addClick(c.pageX - this.offsetLeft, c.pageY - this.offsetTop, true);

                redraw();

            var draw = function(c) {

                     // complétez
                function addClick(x, y, dragging) {
                    clickX.push(x);
                    clickY.push(y);
                    clickDrag.push(dragging);
                }

                function redraw() {

                    context.strokeStyle = c.color;
                    context.lineJoin = "round";
                    context.lineWidth = c.size;
                    context.clickX= c.x;
                    context.clickY= c.y;
                    clickDrag= c.drag;

                    for (var i = 0; i < clickX.length; i++) {
                        context.beginPath();
                        if (clickDrag[i] && i) {
                            context.moveTo(clickX[i - 1], clickY[i - 1]);
                        } else {
                            context.moveTo(clickX[i] - 1, clickY[i]);
                        }
                        context.lineTo(clickX[i], clickY[i]);
                        context.closePath();
                        context.stroke();
                    }

                }
                addClick(c.x - this.offsetLeft, c.y - this.offsetTop, true);

                redraw();
            }
            var clear = function() {
                // complétez
            }

            // étudiez ce bout de code
            var i = 0;
            var iterate = function() {
                if(i>=drawingCommands.length)
                    return;
                var c = drawingCommands[i];
                switch(c.command) {
                    case "start":
                        start(c);
                        break;
                    case "draw":
                        draw(c);
                        break;
                    case "clear":
                        clear();
                        break;
                    default:
                        console.error("cette commande n'existe pas "+ c.command);
                }
                i++;
                setTimeout(iterate,30);
            };

            iterate();

        };

    </script>
</head>
<body>
<canvas id="myCanvas"></canvas>
</body>
</html>